class BookController < ApplicationController
    skip_before_action :verify_authenticity_token
    def readbooks
        books=Book.all
        render json: books
    end
    def add
        books=Book.create(author_id: params[:author_id], title: params[:title], category: params[:category], description: params[:description], year: params[:year])
        render json: books

    end

    def del
        books=Book.find_by_title(params[:title])
        books.destroy
        render json: books
    end

    def update
        books=Book.find(params[:id])
        books.update(description: params[:description])
    end

    def displaybooks
        books=Book.where(author_id: params[:author_id])
        render json: books
    end

    def bookwithauthor
        b=Book.joins(:author).select('*')
        render json:b
    end
end
