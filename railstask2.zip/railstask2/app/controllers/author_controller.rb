class AuthorController < ApplicationController
    skip_before_action :verify_authenticity_token
    def index
        render html:"Hello World"
    end

    def readauthors
        authors=Author.all
        render json: authors
    end

    def add
        authors=Author.create(name: params[:name], phone: params[:phone], email: params[:email], dob: params[:dob])
        render json: authors
    end

    def update
        authors=Author.find(params[:id])
        authors.update(name: params[:name])
        render json: authors
    end
    
    def del
        authors=Author.find(params[:id])
        authors.destroy
        render html: "Author and its book deleted"
    end
end
