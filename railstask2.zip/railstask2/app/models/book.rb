class Book < ApplicationRecord
    belongs_to :author
end
