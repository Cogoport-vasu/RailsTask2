Rails.application.routes.draw do
  # Define your application routes per the DSL in https://guides.rubyonrails.org/routing.html

  # Defines the root path route ("/")
  # root "articles#index"
  get "/", to: "author#index"

  get "/authors", to: "author#readauthors"  
  post "/authors", to: "author#add"
  put "/authors/update/:id", to: "author#update"
  post "/authors/delete/:id", to: "author#del"
  
  post "/display", to: "book#displaybooks"

  get "/books", to: "book#readbooks"
  post "/books", to: "book#add"
  delete "/books/:id", to: "book#del"
  put "/books/update/:id", to: "book#update"
  get "/display", to: "book#bookwithauthor"
end
